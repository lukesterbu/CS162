/**********************************************************************
** Author:      Luke Burris
** Date:        8/6/2018
** Description: Barbarian class definition for fantasy game
**********************************************************************/

#include "fantasyMenu.hpp"

int main()
{
	fantasyMenu();
	
	return 0;  
}
