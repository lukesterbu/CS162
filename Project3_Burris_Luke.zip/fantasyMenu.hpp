/**********************************************************************
** Author:      Luke Burris
** Date:        8/6/2018
** Description: Menu function prototype for fantasy game
**********************************************************************/

#ifndef FANTASYMENU_HPP
#define FANTASYMENU_HPP

void fantasyMenu(); // function prototype

#endif
